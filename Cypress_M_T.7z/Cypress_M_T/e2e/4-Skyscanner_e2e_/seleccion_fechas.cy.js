//PRECONDICIONES
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Seleccion de fechas para viaje", () => {
  before(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://www.skyscanner.com.mx/");
    cy.fixture("sld").then((sld) => {
      this.sld = sld;
      cy.clearLocalStorage();
      cy.clearCookies();
      cy.wait(5000);
    });
  });

  it("01_seleccion de fechas de salida para vuelos, cualquier destino.", function () {
    //   cy.get('#depart-fsc-datepicker-button > .DateInput_DateInput--text__MzMyY').click;

    cy.get(
      "#depart-fsc-datepicker-button > .DateInput_DateInput--text__MzMyY"
    ).click({ force: true });

    cy.get(
      "#depart-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
    ).click({ force: true });
    //Selecciona el mes
    cy.get(
      "#depart-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
    ).click({ force: true });
    cy.get(
      "#depart-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
    ).click({ force: true });
    cy.get(
      "#depart-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
    ).click({ force: true });

    //escoje una fecha central el calendario//
    cy.get(
      ":nth-child(4) > :nth-child(4) > .BpkCalendarDate_bpk-calendar-date__MTdlO > span"
    ).click({ force: true });
  });

  it("02_seleccion de fechas de deregreso para vuelos, cualquier destino.", function () {
    cy.get("#return-fsc-datepicker-button").click({ force: true });

    //Selecciona el mes

    cy.get(
      "#return-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
    ).click({ force: true });
    cy.get(
      "#return-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
    ).click({ force: true });
    cy.get(
      "#return-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
    ).click({ force: true });

    //escoje una fecha central el calendario//
    cy.get(
      ":nth-child(4) > :nth-child(4) > .BpkCalendarDate_bpk-calendar-date__MTdlO > span"
    ).click({ force: true });
  });
  it("03_Selecciona la cantidad de pasajeros.", function () {
    // abre el objeto para la carga de pasajeros
    cy.get(
      "#CabinClassTravellersSelector_fsc-class-travellers-trigger__OTYyM"
    ).click({ force: true });
    cy.wait(5000);

    //aumenta el nro de adultos
    cy.get(
      '[title="Aumentar el número de adultos"] > span > .bpk-nudger__icon > path'
    ).click({ force: true });
    cy.wait(5000);

    //Aumenta el nro de niños ´
    cy.wait(5000);
    cy.get(
      '[title="Aumentar el número de niños"] > span > .bpk-nudger__icon'
    ).click({ force: true });
    //  especifica la edad del niño
    cy.get("#children-age-dropdown-0").select("10"); //.click({force:true});
    cy.wait(5000);
    //  cierra la pantalla empleando ESC
    cy.wait(5000);
    cy.get(
      "#CabinClassTravellersSelector_fsc-class-travellers-trigger__OTYyM"
    ).trigger("keydown", { keyCode: 27 });
  });
});
