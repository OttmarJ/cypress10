//PRECONDICIONES
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("BeforeEach_Hook_Scenarios", () => {
  beforeEach(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://www.mercantilseguros.com/login.html");
    cy.viewport("ipad-2", "landscape");
    cy.fixture("sld").then((sld) => {
      this.sld = sld;
      cy.wait(5000);
    });
  });

  it("Aserciones", function () {
    cy.contains("Portal del Asegurado");
  });
  //});
});
