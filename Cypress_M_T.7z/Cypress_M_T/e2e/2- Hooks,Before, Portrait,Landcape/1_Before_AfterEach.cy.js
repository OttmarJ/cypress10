//PRECONDICIONES
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("01_landscape_View_Scenarios", () => {
  before(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://www.mercantilseguros.com/login.html");
    cy.fixture("sld").then((sld) => {
      this.sld = sld;
      cy.wait(5000);
    });
  });
  it("Login", function () {
    cy.get(
      ".mr-login-left > .login-content > .login-boton-container > .login-cta"
    ).click();
  });
});
