//PRECONDICIONES
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("01_landscape_View_Scenarios", () => {
  before(function () {
    Cypress.config("pageLoadTimeout", 30000);
    cy.visit("https://fastinsuranceservices.net/#/car-1-year");

    cy.viewport("iphone-6+", "portrait");
    cy.fixture("sld").then((sld) => {
      this.sld = sld;
      cy.wait(5000);
    });
  });

  it("proceso parcial de aseguramiento.", function () {
    //  How Many Vehicles Need Coverage?//
    cy.get(":nth-child(1) > .btn > img").click({ force: true });
    cy.wait(5000);

    cy.get(":nth-child(40) > .btn").click({ force: true });
    // Select Vehicle Make//
    cy.wait(5000);
    cy.contains(`Chevrolet`).click({ force: true });

    // Select Vehicle Model//
    cy.wait(5000);
    cy.contains(`Monte Carlo`).click({ force: true });

    // Are You Currently Insured?//
    cy.wait(5000);

    cy.get(
      ".step.active > :nth-child(2) > .col-lg-12 > .row > :nth-child(2) > .btn"
    ).click({ force: true });
    cy.contains(`No`).end();
  });
});
