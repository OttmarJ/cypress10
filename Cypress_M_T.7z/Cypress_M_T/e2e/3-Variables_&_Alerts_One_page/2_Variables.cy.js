/*
fuente:https://www.youtube.com/watch?v=mOvzVxyfzV8
*/


//PRECONDICIONES 
/// <reference types="cypress" />


Cypress.on('uncaught:exception', (err, runnable) => {
  return false;
});
 




describe('Variables_&_Aliases', () => {


  before (function () {  
    Cypress.config('pageLoadTimeout', 30000)
    cy.visit(`https://demoqa.com/modal-dialogs`)
    cy.viewport('ipad-2', 'landscape')
      cy.fixture('sld')
       .then(sld=> {
       this.sld = sld;
        cy.wait(5000) 
      }) 
    })

                 
   it(`Closure_and_Variables`,function() {
   cy.get('#showSmallModal').then($modalbutton =>{
    const smallmodaltext= $modalbutton.text();
    cy.log(smallmodaltext)
    
    $modalbutton.click()
    cy.get('#example-modal-sizes-title-sm').contains(smallmodaltext,{matchCase:false})
    
  })  
})      
//});      
      
it(`Aliases`,function() {
  cy.get('#showSmallModal').invoke(`text`).as(`invoketext`)    
  cy.get('#showSmallModal').then($modalbutton =>{
    const smallmodaltext= $modalbutton.text();
    cy.log(smallmodaltext)
    cy.wrap (smallmodaltext).as(`WrapText`)



  }) 

});  

it(`ShareContext`,function() {
 
  cy.log(this.invoketext)
  cy.log("INVOKE:" +   this.invoketext)
  cy.log("WRAP:" +   this.invoketext)
});
});