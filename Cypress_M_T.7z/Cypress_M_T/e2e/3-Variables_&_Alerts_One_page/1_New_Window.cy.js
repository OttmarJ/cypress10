//PRECONDICIONES
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});
describe(` TEST 1 new tab`, function () {
  it("one page_new tab", function () {
    const stub = cy.stub().as(`open`);
    cy.on(`window:before:load`, (win) => {
      cy.stub(win, `open`), callsFake(stub);
    });
    cy.reload();
    cy.visit("https://demoqa.com/browser-windows");
    cy.get("#tabButton").click();
    //testea el boton sin abrir la pantalla ASERSION implicita
  });
});

it(" TEST4  one page_new tab", function () {
  cy.visit("https://demoqa.com/browser-windows");
  cy.window().then((win) => {
    const stub = cy.stub();

    cy.on(`window:before:load`, (win) => {
      win.location.href = "https://demoqa.com/sample ";
      cy.stub(win, `open`), callsFake(stub);
      //TESTEA EL BOTON ABRIENDO LA VENTANA
      //creo que hay que testear o averiguar si hay un Iframe
    });
  });

  cy.reload();
  cy.visit("https://demoqa.com/browser-windows");
  cy.contains("This is a sample page");
});

it(" TEST5  new window", function () {
  cy.visit("https://demoqa.com/browser-windows");
  cy.get("#windowButton").click();
  //apertura el modal la prueba dedbe incluir el cierre del mismo la la pantalla habra dentro
  //misma instancia de cypress
  //
});

it(" TEST6 new window", function () {
  cy.visit("https://demoqa.com/browser-windows");
  cy.get("#messageWindowButton").click({ force: true });

  cy.title("Sin titulo");

  cy.title(
    "Knowledge increases by sharing but not by saving. Please share this website with your friends and in your organization.Knowledge increases by sharing but not by saving. Please share this website with your friends and in your organization. "
  );

  //  abre el modal  y testea mediante asersion d
});
