/*
//PRECONDICION
No requiere del uso de liabreria adicionales 
requiere de conocer promesa
para que la escritura  sea totalmente limpia 
se intercala el uso de wait
ref:https://www.youtube.com/watch?v=p_24e-4ujgY

*/
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

it("Iframe_Cypress_Bug", function () {
  // launch URL
  cy.visit("http://the-internet.herokuapp.com/iframe");
  cy.get("#mce_0_ifr").then(function ($Iframe) {
    const iframeContent = $Iframe.contents().find("body");
    cy.wrap(iframeContent).click().clear().wait(3000).type("hello");
  });
});
