//PRECONDICIONES
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("03_type_ &_Clear_Scenario", () => {
  // });

  it("Scroll", function () {
    cy.visit("https://codenboxautomationlab.com/");
    cy.wait(3000);
    cy.contains("Contact Us").scrollIntoView();
    cy.wait(3000);
    cy.get(".block-editor-rich-text__editable > span").scrollIntoView();
    cy.get("#menu-item-63 > .sf-with-ul").click();
  });
});
