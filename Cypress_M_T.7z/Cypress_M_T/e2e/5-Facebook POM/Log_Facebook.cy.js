/*
fuente:https://www.youtube.com/watch?v=mOvzVxyfzV8
*/


//PRECONDICIONES 
//
import facebook from "./facebook"
 

describe('Facebook_log', () => {
                    
  before (() => {
   
    cy.visit('https://es-la.facebook.com/')       

      });
    
      it.only('01.Contraseñas correctas',function(){
       facebook.typeUsername(`standard_user`)
       facebook.typePassword(`standard_user`)  
        facebook.clickLogin() 
});       

it('02_Contraseñas incorrectas.',function(){
  facebook.typeUsername(`standard_user`)
  facebook.typePassword(`standard_user`)  

    });

    it('03_Usuario_Correcto/Contraseña_Incorrecta.',function(){
      facebook.typeUsername(`standard_user`)
      facebook.typePassword(`standard_user`)  
  });    

  it('04_Usuario_Incorrecto/Contraseña_Correcta.',function(){
    facebook.typeUsername(`standard_user`)
    facebook.typePassword(`standard_user`)  

  }); 
});  