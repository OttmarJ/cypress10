
class facebook{

    elements={
        usernameInput: ()=>cy.get('[data-testid="royal_email"]'),
        passwordInput: ()=> cy.get('[data-testid="royal_pass"]'),
        loginBtn: ()=>     cy.get('[data-testid="royal_login_button"]'),
    
    
    }
    typeUsername(username){
        this.elements.usernameInput().type(username)
    
    }
    
    typePassword(password){
        this.elements.passwordInput().type(password)
    }
    
    clickLogin(){
    
        this.elements.loginBtn().click
    }
    
    }
    module.exports= new facebook();