describe(`multidomain`, function () {
  it(`Skyscanner`, function () {
    Cypress.on("uncaught:exception", (err, runnable) => {
      return false;
    });
    cy.visit("https://www.skyscanner.com.mx/");
    cy.fixture("sld").then((sld) => {
      this.sld = sld;
      cy.clearLocalStorage();
      cy.clearCookies();
      cy.wait(5000);

      //   cy.get('#depart-fsc-datepicker-button > .DateInput_DateInput--text__MzMyY').click;

      cy.get(
        "#depart-fsc-datepicker-button > .DateInput_DateInput--text__MzMyY"
      ).click({ force: true });

      cy.get(
        "#depart-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
      ).click({ force: true });
      //Selecciona el mes
      cy.get(
        "#depart-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
      ).click({ force: true });
      cy.get(
        "#depart-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
      ).click({ force: true });
      cy.get(
        "#depart-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
      ).click({ force: true });
      // seleccion de fechas de deregreso para vuelos, cualquier destino

      cy.get("#return-fsc-datepicker-button").click({ force: true });

      //Selecciona el mes

      cy.get(
        "#return-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
      ).click({ force: true });
      cy.get(
        "#return-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
      ).click({ force: true });
      cy.get(
        "#return-calendar__bpk_calendar_nav_month_nudger_next > .BpkCalendarNav_bpk-calendar-nav__icon__Yjc0N"
      ).click({ force: true });

      //escoje una fecha central el calendario//
      cy.get(
        ":nth-child(4) > :nth-child(4) > .BpkCalendarDate_bpk-calendar-date__MTdlO > span"
      ).click({ force: true });

      // abre el objeto para la carga de pasajeros
      cy.get(
        "#CabinClassTravellersSelector_fsc-class-travellers-trigger__OTYyM"
      ).click({ force: true });
      cy.wait(5000);

      //aumenta el nro de adultos
      cy.get(
        '[title="Aumentar el número de adultos"] > span > .bpk-nudger__icon > path'
      ).click({ force: true });
      cy.wait(5000);

      //Aumenta el nro de niños ´
      cy.wait(5000);
      cy.get(
        '[title="Aumentar el número de niños"] > span > .bpk-nudger__icon'
      ).click({ force: true });
      //  especifica la edad del niño
      cy.get("#children-age-dropdown-0").select("10"); //.click({force:true});
      cy.wait(5000);
      //  cierra la pantalla empleando ESC
      cy.wait(5000);
      cy.get(
        "#CabinClassTravellersSelector_fsc-class-travellers-trigger__OTYyM"
      ).trigger("keydown", { keyCode: 27 });
    });
  });

  it(`Google acoounts`, function () {
    cy.visit(
      `https://accounts.google.com/signin/v2/identifier?hl=es&flowName=GlifWebSignIn&flowEntry=ServiceLogin`
    );

    //cy.clearLocalStorage()
    //cy.clearCookies()

    cy.get(`[name="identifier"]`).type("Amador01@gmail.com", { force: true });
    cy.contains(`Siguiente`).click({ force: true });
    cy.wait(5000);
    cy.contains("No se ha podido iniciar sesión");
    /*
    cy.get(`#password`).type("Yyyyyy", { force: true });
    cy.contains(`Siguiente`).click({ force: true });
    cy.get(".gb_Te").click({ force: true });
    cy.wait(5000);
    */
  });
});
