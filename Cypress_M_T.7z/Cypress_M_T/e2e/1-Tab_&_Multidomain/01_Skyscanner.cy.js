//PRECONDICION
//requiere de la instalacion del plugin tab npm install -D cypress-plugin-tab
//npm install -D cypress-plugin-tab
//At the top of cypress/support/index.js:
//require('cypress-plugin-tab')
/// <reference types="cypress" />

Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

describe("Tab_ ", () => {
  it("Tab", function () {
    cy.visit(" https://www.skyscanner.com.mx/");

    //cy.get(".cxMOTc > .rFrNMe > .aCsJod > .aXBtI > .i9lrp").tab();
    //  cy.get("body").tab();

    cy.get("#culture-info > .BpkButtonBase_bpk-button__NmMxY").focus();
    cy.get("#culture-info > .BpkButtonBase_bpk-button__NmMxY").tab();

    // );
  });
});
